"""50 beginner Python conditional and match-case programs.
Run this file and choose a program from the menu. Requires Python 3.10+ for match-case.
"""


# ====================================================================
# Program 1: 1. Positive or Negative
# ====================================================================

n = int(input("Enter a number: "))
if n > 0:
    print("Positive number")
elif n < 0:
    print("Negative number")
else:
    print("Neither positive nor negative")



# ====================================================================
# Program 2: 2. Even or Odd
# ====================================================================

n = int(input("Enter a number: "))
if n % 2 == 0:
    print("Even number")
else:
    print("Odd number")



# ====================================================================
# Program 3: 3. Voting Eligibility
# ====================================================================

age = int(input("Enter your age: "))
if age >= 18:
    print("Eligible to vote")
else:
    print("Not eligible to vote")



# ====================================================================
# Program 4: 4. Greater than 100
# ====================================================================

n = int(input("Enter a number: "))
if n > 100:
    print("Number is greater than 100")
else:
    print("Number is not greater than 100")



# ====================================================================
# Program 5: 5. Leap Year
# ====================================================================

year = int(input("Enter a year: "))
if year % 400 == 0 or (year % 4 == 0 and year % 100 != 0):
    print("Leap year")
else:
    print("Not a leap year")



# ====================================================================
# Program 6: 6. Greater of Two Numbers
# ====================================================================

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
if a > b:
    print("Greater number:", a)
elif b > a:
    print("Greater number:", b)
else:
    print("Both numbers are equal")



# ====================================================================
# Program 7: 7. Vowel or Consonant
# ====================================================================

ch = input("Enter a character: ").lower()
if len(ch) == 1 and ch in "aeiou":
    print("Vowel")
elif len(ch) == 1 and ch.isalpha():
    print("Consonant")
else:
    print("Invalid character")



# ====================================================================
# Program 8: 8. Divisible by 5
# ====================================================================

n = int(input("Enter a number: "))
if n % 5 == 0:
    print("Divisible by 5")
else:
    print("Not divisible by 5")



# ====================================================================
# Program 9: 9. Pass or Fail
# ====================================================================

marks = int(input("Enter marks: "))
if marks >= 40:
    print("Pass")
else:
    print("Fail")



# ====================================================================
# Program 10: 10. Single-Digit Number
# ====================================================================

n = int(input("Enter a number: "))
if -9 <= n <= 9:
    print("Single-digit number")
else:
    print("Not a single-digit number")



# ====================================================================
# Program 11: 11. Hot or Cold
# ====================================================================

temp = float(input("Enter temperature: "))
if temp > 30:
    print("Hot")
else:
    print("Cold")



# ====================================================================
# Program 12: 12. Child or Adult
# ====================================================================

age = int(input("Enter age: "))
if age < 0:
    print("Invalid age")
elif age < 18:
    print("Child")
else:
    print("Adult")



# ====================================================================
# Program 13: 13. Zero or Non-zero
# ====================================================================

n = int(input("Enter a number: "))
if n == 0:
    print("Zero")
else:
    print("Non-zero")



# ====================================================================
# Program 14: 14. Uppercase or Lowercase
# ====================================================================

ch = input("Enter a character: ")
if len(ch) == 1 and ch.isupper():
    print("Uppercase")
elif len(ch) == 1 and ch.islower():
    print("Lowercase")
else:
    print("Not an uppercase or lowercase letter")



# ====================================================================
# Program 15: 15. Divisible by Both 3 and 7
# ====================================================================

n = int(input("Enter a number: "))
if n % 3 == 0 and n % 7 == 0:
    print("Divisible by both 3 and 7")
else:
    print("Not divisible by both 3 and 7")



# ====================================================================
# Program 16: 16. Greatest of Three Numbers
# ====================================================================

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = int(input("Enter third number: "))
if a >= b and a >= c:
    print("Greatest:", a)
elif b >= a and b >= c:
    print("Greatest:", b)
else:
    print("Greatest:", c)



# ====================================================================
# Program 17: 17. Grade Based on Marks
# ====================================================================

marks = int(input("Enter marks (0-100): "))
if not 0 <= marks <= 100:
    print("Invalid marks")
elif marks >= 80:
    print("Grade A")
elif marks >= 60:
    print("Grade B")
elif marks >= 40:
    print("Grade C")
else:
    print("Fail")



# ====================================================================
# Program 18: 18. Positive, Negative, or Zero
# ====================================================================

n = int(input("Enter a number: "))
if n > 0:
    print("Positive")
elif n < 0:
    print("Negative")
else:
    print("Zero")



# ====================================================================
# Program 19: 19. Day Name (1-7)
# ====================================================================

day = int(input("Enter day number (1-7): "))
if day == 1:
    print("Monday")
elif day == 2:
    print("Tuesday")
elif day == 3:
    print("Wednesday")
elif day == 4:
    print("Thursday")
elif day == 5:
    print("Friday")
elif day == 6:
    print("Saturday")
elif day == 7:
    print("Sunday")
else:
    print("Invalid day number")



# ====================================================================
# Program 20: 20. Ticket Price by Age
# ====================================================================

age = int(input("Enter age: "))
if age < 0:
    print("Invalid age")
elif age < 5:
    print("Ticket is free")
elif age < 18:
    print("Ticket price: Rs. 50")
elif age < 60:
    print("Ticket price: Rs. 100")
else:
    print("Ticket price: Rs. 60")



# ====================================================================
# Program 21: 21. Smallest of Three Numbers
# ====================================================================

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = int(input("Enter third number: "))
if a <= b and a <= c:
    print("Smallest:", a)
elif b <= a and b <= c:
    print("Smallest:", b)
else:
    print("Smallest:", c)



# ====================================================================
# Program 22: 22. Salary Bonus by Years of Service
# ====================================================================

salary = float(input("Enter salary: "))
years = int(input("Enter years of service: "))
if salary < 0 or years < 0:
    print("Invalid input")
elif years >= 5:
    bonus = salary * 0.10
    print("Bonus:", bonus)
else:
    print("No bonus")



# ====================================================================
# Program 23: 23. Electricity Bill
# ====================================================================

units = int(input("Enter units consumed: "))
if units < 0:
    print("Invalid units")
elif units <= 100:
    bill = units * 5
    print("Electricity bill:", bill)
elif units <= 200:
    bill = 100 * 5 + (units - 100) * 7
    print("Electricity bill:", bill)
else:
    bill = 100 * 5 + 100 * 7 + (units - 200) * 10
    print("Electricity bill:", bill)



# ====================================================================
# Program 24: 24. Exam Result
# ====================================================================

marks = int(input("Enter marks (0-100): "))
if not 0 <= marks <= 100:
    print("Invalid marks")
elif marks >= 75:
    print("Distinction")
elif marks >= 60:
    print("First Class")
elif marks >= 40:
    print("Pass")
else:
    print("Fail")



# ====================================================================
# Program 25: 25. Triangle Type
# ====================================================================

a = int(input("Enter first side: "))
b = int(input("Enter second side: "))
c = int(input("Enter third side: "))
if a <= 0 or b <= 0 or c <= 0 or a + b <= c or a + c <= b or b + c <= a:
    print("Invalid triangle")
elif a == b == c:
    print("Equilateral triangle")
elif a == b or b == c or a == c:
    print("Isosceles triangle")
else:
    print("Scalene triangle")



# ====================================================================
# Program 26: 26. Month Name
# ====================================================================

month = int(input("Enter month number (1-12): "))
if month == 1:
    print("January")
elif month == 2:
    print("February")
elif month == 3:
    print("March")
elif month == 4:
    print("April")
elif month == 5:
    print("May")
elif month == 6:
    print("June")
elif month == 7:
    print("July")
elif month == 8:
    print("August")
elif month == 9:
    print("September")
elif month == 10:
    print("October")
elif month == 11:
    print("November")
elif month == 12:
    print("December")
else:
    print("Invalid month number")



# ====================================================================
# Program 27: 27. Login Status
# ====================================================================

username = input("Enter username: ")
password = input("Enter password: ")
if username == "admin" and password == "1234":
    print("Login successful")
else:
    print("Invalid username or password")



# ====================================================================
# Program 28: 28. Shopping Discount
# ====================================================================

amount = float(input("Enter shopping amount: "))
if amount < 0:
    print("Invalid amount")
else:
    if amount >= 5000:
        discount = amount * 0.20
    elif amount >= 2000:
        discount = amount * 0.10
    else:
        discount = 0
    print("Discount:", discount)
    print("Final amount:", amount - discount)



# ====================================================================
# Program 29: 29. Basic Blood Donation Criteria
# ====================================================================

age = int(input("Enter age: "))
weight = float(input("Enter weight in kg: "))
if 18 <= age <= 65 and weight >= 50:
    print("Meets basic age and weight criteria")
else:
    print("Does not meet basic criteria")
print("Final eligibility requires medical screening.")



# ====================================================================
# Program 30: 30. Number of Digits
# ====================================================================

n = abs(int(input("Enter a number: ")))
if n <= 9:
    print("Single-digit number")
elif n <= 99:
    print("Two-digit number")
elif n <= 999:
    print("Three-digit number")
else:
    print("More than three digits")



# ====================================================================
# Program 31: 31. Positive and Even Using Nested If
# ====================================================================

n = int(input("Enter a number: "))
if n > 0:
    if n % 2 == 0:
        print("Positive and even")
    else:
        print("Positive but odd")
else:
    print("Number is not positive")



# ====================================================================
# Program 32: 32. Exam Eligibility
# ====================================================================

attendance = float(input("Enter attendance percentage: "))
marks = int(input("Enter marks: "))
if attendance >= 75:
    if marks >= 40:
        print("Eligible for exam")
    else:
        print("Not eligible: insufficient marks")
else:
    print("Not eligible: low attendance")



# ====================================================================
# Program 33: 33. Loan Application Criteria
# ====================================================================

age = int(input("Enter age: "))
salary = float(input("Enter monthly salary: "))
if age >= 21:
    if salary >= 25000:
        print("Eligible to apply for loan")
    else:
        print("Salary is insufficient")
else:
    print("Age requirement not met")



# ====================================================================
# Program 34: 34. Leap Year and Century Year
# ====================================================================

year = int(input("Enter year: "))
if year <= 0:
    print("Invalid year")
else:
    if year % 100 == 0:
        print("Century year")
        if year % 400 == 0:
            print("Leap year")
        else:
            print("Not a leap year")
    else:
        if year % 4 == 0:
            print("Leap year")
        else:
            print("Not a leap year")



# ====================================================================
# Program 35: 35. Divisible by 3 and 5
# ====================================================================

n = int(input("Enter a number: "))
if n % 3 == 0 and n % 5 == 0:
    print("Divisible by both 3 and 5")
else:
    print("Not divisible by both 3 and 5")



# ====================================================================
# Program 36: 36. Driving Licence Eligibility
# ====================================================================

age = int(input("Enter age: "))
if age >= 18:
    print("Eligible to apply for driving licence")
else:
    print("Not eligible for driving licence")



# ====================================================================
# Program 37: 37. Between 10 and 50
# ====================================================================

n = int(input("Enter a number: "))
if 10 <= n <= 50:
    print("Number lies between 10 and 50")
else:
    print("Number is outside the range")



# ====================================================================
# Program 38: 38. Passed All Subjects
# ====================================================================

m1 = int(input("Enter marks for subject 1: "))
m2 = int(input("Enter marks for subject 2: "))
m3 = int(input("Enter marks for subject 3: "))
if m1 >= 40 and m2 >= 40 and m3 >= 40:
    print("Passed all subjects")
else:
    print("Failed in one or more subjects")



# ====================================================================
# Program 39: 39. Greater than 0 and Less than 100
# ====================================================================

n = int(input("Enter a number: "))
if n > 0 and n < 100:
    print("Number is between 0 and 100")
else:
    print("Number is not between 0 and 100")



# ====================================================================
# Program 40: 40. Valid Password Using Nested If
# ====================================================================

password = input("Enter password: ")
if len(password) >= 8:
    if any(ch.isdigit() for ch in password):
        print("Valid password")
    else:
        print("Password must contain a digit")
else:
    print("Password must have at least 8 characters")



# ====================================================================
# Program 41: 41. Weekday Using match-case
# ====================================================================

day = int(input("Enter day number (1-7): "))
match day:
    case 1:
        print("Monday")
    case 2:
        print("Tuesday")
    case 3:
        print("Wednesday")
    case 4:
        print("Thursday")
    case 5:
        print("Friday")
    case 6:
        print("Saturday")
    case 7:
        print("Sunday")
    case _:
        print("Invalid day number")



# ====================================================================
# Program 42: 42. Calculator Using match-case
# ====================================================================

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
op = input("Enter operator (+, -, *, /): ")
match op:
    case "+":
        print("Result:", a + b)
    case "-":
        print("Result:", a - b)
    case "*":
        print("Result:", a * b)
    case "/":
        if b != 0:
            print("Result:", a / b)
        else:
            print("Cannot divide by zero")
    case _:
        print("Invalid operator")



# ====================================================================
# Program 43: 43. Month Days Using match-case
# ====================================================================

month = int(input("Enter month number (1-12): "))
match month:
    case 1 | 3 | 5 | 7 | 8 | 10 | 12:
        print("31 days")
    case 4 | 6 | 9 | 11:
        print("30 days")
    case 2:
        print("28 days in a non-leap year")
    case _:
        print("Invalid month number")



# ====================================================================
# Program 44: 44. Traffic Signal Using match-case
# ====================================================================

signal = input("Enter traffic signal: ").lower()
match signal:
    case "red":
        print("Stop")
    case "yellow":
        print("Wait")
    case "green":
        print("Go")
    case _:
        print("Invalid signal")



# ====================================================================
# Program 45: 45. Food Menu Using match-case
# ====================================================================

print("1. Pizza")
print("2. Burger")
print("3. Sandwich")
print("4. Dosa")
choice = int(input("Enter your choice: "))
match choice:
    case 1:
        print("You selected Pizza")
    case 2:
        print("You selected Burger")
    case 3:
        print("You selected Sandwich")
    case 4:
        print("You selected Dosa")
    case _:
        print("Invalid choice")



# ====================================================================
# Program 46: 46. Grade Description Using match-case
# ====================================================================

grade = input("Enter grade (A/B/C/F): ").upper()
match grade:
    case "A":
        print("Excellent")
    case "B":
        print("Very Good")
    case "C":
        print("Good")
    case "F":
        print("Fail")
    case _:
        print("Invalid grade")



# ====================================================================
# Program 47: 47. User Role Using match-case
# ====================================================================

role = input("Enter role: ").lower()
match role:
    case "admin":
        print("Full access")
    case "user":
        print("Normal access")
    case "guest":
        print("Limited access")
    case _:
        print("Invalid role")



# ====================================================================
# Program 48: 48. Language Choice Using match-case
# ====================================================================

print("1. English")
print("2. Marathi")
print("3. Hindi")
choice = int(input("Choose language: "))
match choice:
    case 1:
        print("You selected English")
    case 2:
        print("You selected Marathi")
    case 3:
        print("You selected Hindi")
    case _:
        print("Invalid choice")



# ====================================================================
# Program 49: 49. Result Status Using match-case
# ====================================================================

status = input("Enter result status (pass/fail/absent): ").lower()
match status:
    case "pass":
        print("Congratulations! You passed.")
    case "fail":
        print("Better luck next time.")
    case "absent":
        print("You were absent.")
    case _:
        print("Invalid status")



# ====================================================================
# Program 50: 50. ATM Menu Using match-case
# ====================================================================

balance = 5000.0
print("1. Check Balance")
print("2. Deposit Money")
print("3. Withdraw Money")
print("4. Exit")
choice = int(input("Enter your choice: "))
match choice:
    case 1:
        print("Balance:", balance)
    case 2:
        amount = float(input("Enter deposit amount: "))
        if amount > 0:
            balance += amount
            print("Updated balance:", balance)
        else:
            print("Invalid amount")
    case 3:
        amount = float(input("Enter withdrawal amount: "))
        if amount <= 0:
            print("Invalid amount")
        elif amount <= balance:
            balance -= amount
            print("Remaining balance:", balance)
        else:
            print("Insufficient balance")
    case 4:
        print("Thank you for using ATM")
    case _:
        print("Invalid choice")

